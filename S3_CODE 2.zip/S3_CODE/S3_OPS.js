
var prjBucketName = 'cloudproj1s3bucket';
var prjbucketRegion = 'us-east-1'
var prjIdentityPoolId = 'PUT YOUR IDENTITY POOL ID';

AWS.config.update({
  region: prjbucketRegion,
  credentials: new AWS.CognitoIdentityCredentials({
    IdentityPoolId: prjIdentityPoolId
  })
});

AWS.config.credentials.get(function(){

   
    var accessKeyId = AWS.config.credentials.accessKeyId;
    var secretAccessKey = AWS.config.credentials.secretAccessKey;
    var sessionToken = AWS.config.credentials.sessionToken;

});

var prjS3 = new AWS.S3({
  apiVersion: '2006-03-01',
  params: {Bucket: prjBucketName}
});

function listFolders() {
  prjS3.listObjects({Delimiter: '/'}, function(err, data) {
    if (err) {
      return alert('There was an error listing your recipes: ' + err.message);
    } else {
      var folders = data.CommonPrefixes.map(function(commonPrefix) {
        var prefix = commonPrefix.Prefix;
        var folderName = decodeURIComponent(prefix.replace('/', ''));
        return getHtml([
          '<table class="table table-striped">',
            '<thead>',
              '<tr>',
                '<th>#</th>',
                '<th>Folder Name</th>',
                '<th>Options</th>',
              '</tr>',
            '</thead>',
            '<tbody>',
              '<tr>',
                '<td>1</td>',
                '<td>','<em onclick="viewFolder(\'' + folderName + '\')">',
              folderName,
                    '</em>',
                '</td>',
                '<td>','<em onclick="deleteFolder(\'' + folderName + '\')">Delete</em>',
                '</td>',
              '</tr>',  
          '</table>'
    ]);
      });
      var message = folders.length ?
        getHtml([
          '<p>Click on Receipe folder to view your receipes</p>',
         ]) :
        '<p>You do not have any Recipe folder. Please add some yummy recipes.</p>';
      var htmlTemplate = [
        '<h2>Folder</h2>',
        message,
        '<ul>',
          getHtml(folders),
        '</ul>'
        
            ]
      document.getElementById('app').innerHTML = getHtml(htmlTemplate);
    }
  });
}

function viewFolder(folderName) {
  var folderFilesKey = encodeURIComponent(folderName) + '//';
 

  prjS3.listObjects({Prefix: folderFilesKey}, function(err, data) {
    if (err) {
      return alert('There was an error viewing your recipe: ' + err.message);
    }
    // `this` references the AWS.Response instance that represents the response
    var href = this.request.httpRequest.endpoint.href;
    var bucketUrl = href + prjBucketName + '/';

    var files = data.Contents.map(function(file) {
      var fileKey = file.Key;
      var fileUrl = bucketUrl + encodeURIComponent(fileKey);
      return getHtml([
	      
	      '<div>',
	      '<em>',
              fileKey.replace(folderFilesKey, ''),
            '</em>','<em>','&nbsp;',
          
          '<button>',
          '<a color = "white" href="'+fileUrl+'"><font color="black">Download Recipe</font></a>','&nbsp;','</button>',
            
          '</em>','<button>','<em onclick="deleteFile(\'' + folderName + "','" + fileKey + '\')">','<u>','Delete Recipe','</u>',
            '</em>','</button>',
                     '</div>'
        
      ]);
      getObjDetail(fileKey);
    });
    
    var message = files.length ?
      '<p>Files</p>' :
      '<p>You do not have any recipes. Please add some.</p>';
    var htmlTemplate = [
      '<h2>',
        'Folder: ' + folderName,
      '</h2>',
      message,
      '<div>',
        getHtml(files),
      '</div>',
      '<input id="fileupload" type="file" accept="file_extension">',
      '<button id="upload" onclick="addFile(\'' + folderName +'\')">',
        'Upload',
      '</button>',
      '<button onclick="listFolders()">',
        'Back To Yummy Menu',
      '</button>',
    ]
    document.getElementById('app').innerHTML = getHtml(htmlTemplate);
  });
}

function createFolder(folderName) {
  folderName = folderName.trim();
  if (!folderName) {
    return alert('Menu names must contain at least one non-space character.');
  }
  if (folderName.indexOf('/') !== -1) {
    return alert('Menu names cannot contain slashes.');
  }
  var folderKey = encodeURIComponent(folderName) + '/';
  prjS3.headObject({Key: folderKey}, function(err, data) {
    if (!err) {
      return alert('Menu already exists.');
    }
    if (err.code !== 'NotFound') {
      return alert('There was an error creating your Menu: ' + err.message);
    }
    prjS3.putObject({Key: folderKey}, function(err, data) {
      if (err) {
        return alert('There was an error creating your Menu: ' + err.message);
      }
      alert('Successfully created Menu.');
      viewFolder(folderName);
    });
  });
}
function addFile(folderName) {
  var files = document.getElementById('fileupload').files;
  if (!files.length) {
    return alert('Please choose a recipe to upload first.');
  }
  var file = files[0];
  var fileName = file.name;
  var folderFilesKey = encodeURIComponent(folderName) + '//';

  var fileKey = folderFilesKey + fileName;
  prjS3.upload({
    Key: fileKey,
    Body: file,
    ACL: 'public-read'
  }, function(err, data) {
    if (err) {
      return alert('There was an error uploading your recipe: ', err.message);
    }
    alert('Successfully uploaded recipe.');
    viewFolder(folderName);
    
  });
}

function deleteFile(folderName, fileKey) {
  prjS3.deleteObject({Key: fileKey}, function(err, data) {
    if (err) {
      return alert('There was an error deleting your recipe: ', err.message);
    }
    alert('Successfully deleted file.');
    viewFolder(folderName);
  });
}

function getObjDetail(fileKey) {
var params = {
  Bucket: "prjS3", 
  Key: fileKey, 
  
 };
 
 }


