var url = require('url');
var fs = require('fs');
framework.helpers.bootstrap = require("node-bootstrap-html");

function renderHTML(path, response) {
    fs.readFile(path, null, function(error, data) {
        if (error) {
            response.writeHead(404);
            response.write('File not found!');
        } else {
            response.write(data);
        }
        response.end();
    });
}

module.exports = {
  handleRequest: function(request, response) {
      response.writeHead(200, {'Content-Type': 'text/html'});

      var path = url.parse(request.url).pathname;
      switch (path) {
          case '/main':
              renderHTML('./main_s3.html', response);
              break;
              	case '/index':
              renderHTML('../../../../../Downloads/bootstrap-3.3.7/docs/examples/cover/index.html', response);
              break;

          case '/add':
              renderHTML('./add_receipe_s3.html', response);
              break;
          default:
              response.writeHead(404);
              response.write('Route not defined');
              response.end();
      }

  }
};