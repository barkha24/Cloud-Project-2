/*Below is initial start file contents*/

/*var http = require('http');
var app = require('./app');


http.createServer(app.handleRequest).listen(8000);*/


var express = require("express");
var app = express();
var router = express.Router();
var path = __dirname + '/views/';

router.use(function (req,res,next) {
  console.log("/" + req.method);
  next();
});

router.get("/",function(req,res){
  res.sendFile(path + "main_s3.html");
});

router.get("/about",function(req,res){
  res.sendFile(path + "about.html");
});

router.get("/add",function(req,res){
  res.sendFile(path + "add_receipe_s3.html");
});

app.use("/",router);

app.use("*",function(req,res){
  res.sendFile(path + "main_s3.html");
});

app.listen(8000,function(){
  console.log("Live at Port 8000");
});