<?php

/*
 * Define Amazon constants
 */


interface AmazonConstants{

    const S3_ACCESSKEY            = 'S3access_key';
    const S3_SECRETKEY            = 'secret key';
    const BUCKETNAME              = 'bucketname';

}


?>